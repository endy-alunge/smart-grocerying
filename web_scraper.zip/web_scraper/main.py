#required libraries
import requests
from bs4 import BeautifulSoup
import pandas as pd

#http requests to websites and parsing html content
#_____________________________________________________________________________
#https://products.checkers.co.za/c-2413/All-Departments/Food
#https://www.woolworths.co.za/cat/Food/Milk-Dairy-Eggs/_/N-1sqo44p
#https://www.shoprite.co.za/c-95/All-Departments/Food/Fresh-Food
#https://www.makro.co.za/all/pr?sid=all&otracker=categorytree
#https://www.pnp.co.za/c/pnpbase (The last scrapping left, work on html)
#_____________________________________________________________________________

#browser headers for checkers and shoprite
headers = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/114.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

url = "https://www.pnp.co.za/c/pnpbase"
response = requests.get(url, headers=headers)
soup = BeautifulSoup(response.text,'html.parser')

#extracting products prices and store them
product_name = soup.find_all(
    lambda tag: (
        (tag.name == "a" and "range--title" in tag.get("class", [])) or
        (tag.name == "h2" and "product-card__name" in tag.get("class", [])) or
        (tag.name == "h3" and "item-product__name" in tag.get("class", [])) or
        (tag.name == "a" and "s1Q9rs" in tag.get("class", [])) # Makro
    )
)

product_price = soup.find_all(
    lambda tag: (
        (tag.name == "strong" and "price" in tag.get("class", [])) or
        (tag.name == "span" and "now" in tag.get("class", [])) or
        (tag.name == "span" and "_8TW4TR" in tag.get("class", [])) #still scrapping incorrect prices
    )
)

#printing out stored data
for name, price in zip(product_name, product_price):
    print(name.text+ " - "+price.text)
    
